# Project Notes
v. 0.1.0.pa


version: major.minor.patch.stage

stages: Pre-Alpha, Alpha, Beta, Release-Candidate




## Project records and notes

### Audio

## From freesound.org creator almusic34
Creepy: space3, space7, deep space
Explore Unknown: space1, space5
EpicRealization: space4
Grand/Surreal: echo.mp3
Lonely/Sad: Space7
CreepyExplore: space 6 (too slow?)
Unobtrusive: Quiet Space.mp3
Uneasy, Machiney: Drone.mp3

### Sprites

* Sprites should be scaled up to 2x size
* Sprites include pixel-free areas within .pngs. The size of the sprite must perfectly fit the collision box.

