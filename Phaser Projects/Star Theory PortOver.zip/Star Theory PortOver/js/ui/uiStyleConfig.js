const buttonConfig = {
    targets: this,
    duration: 300,
    scaleX: 1.2,
    scaleY: 1.2
}
