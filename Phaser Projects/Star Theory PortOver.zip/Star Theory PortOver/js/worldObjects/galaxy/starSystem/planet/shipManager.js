'use strict';

class ShipManager {
    constructor() {

    }


};
