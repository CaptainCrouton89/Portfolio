'use strict';

class QuestPool {

    constructor(planet) {
    }
};
