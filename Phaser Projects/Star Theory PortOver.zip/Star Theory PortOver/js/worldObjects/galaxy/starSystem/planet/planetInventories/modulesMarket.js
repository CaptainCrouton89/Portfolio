'use strict';

class ModulesMarket extends Market {

    constructor(planet) {
        super(planet);
    }
};
