'use strict';

class CrewMarket extends Market {

    constructor(planet) {
        super(planet);
    }
};
