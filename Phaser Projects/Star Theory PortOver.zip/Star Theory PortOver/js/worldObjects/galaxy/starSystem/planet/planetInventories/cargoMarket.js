'use strict';

class CargoMarket extends Market {

    constructor(planet) {
        super(planet);
    }
};
