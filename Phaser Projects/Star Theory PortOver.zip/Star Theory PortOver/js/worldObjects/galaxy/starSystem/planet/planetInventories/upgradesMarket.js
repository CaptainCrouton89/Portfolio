'use strict';

class UpgradesMarket extends Market {

    constructor(planet) {
        super(planet);

    }
};
