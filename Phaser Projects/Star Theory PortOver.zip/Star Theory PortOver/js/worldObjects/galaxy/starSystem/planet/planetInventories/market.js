'use strict';

class Market {

    constructor(planet) {
        this.planet = planet;
    }
};
