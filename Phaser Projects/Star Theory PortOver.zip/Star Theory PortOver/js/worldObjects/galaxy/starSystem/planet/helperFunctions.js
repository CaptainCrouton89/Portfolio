'use strict';

class helper {

    static getRandomFloat(min, max) {
        return Math.random() * (max - min) + min;
    }
};
