'use strict';

class PlayerShip extends Ship {

    constructor(captain) {
        super(captain);
    }
};
