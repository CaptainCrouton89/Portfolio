'use strict';

class Inventory {

    constructor(inventoryManager) {
        this.inventoryManager = inventoryManager;

    }


};
