"use strict"

class TemplateScene extends MenuScene {

    constructor(config) {
        super(config);
        this.name = "sceneName";
        this.keyboardConfig["char"] = foo;
    }

    init () {
        super.init();
    }

    preload () {
        super.preload();
    }
    
    create () {
        super.create();
    }

    update () {
        super.update();
    }
}

function foo () {
    
}