"use strict"

class QuestMenu {

    constructor(planet) {
        this.planet = planet;
    }
}